import React from 'react';
import { useParams } from 'react-router-dom';
import PropertyDetailAdmin from '../../components/PropertyDetailAdmin';

function PropertyView() {
  const { id } = useParams();

  return (
    <div>
      <PropertyDetailAdmin propertyId={parseInt(id)} onClose={() => window.history.back()} />
    </div>
  );
}

export default PropertyView;