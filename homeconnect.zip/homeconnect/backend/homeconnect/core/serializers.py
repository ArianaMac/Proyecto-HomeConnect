from rest_framework import serializers
from core.models import Notificacion, Usuario, Mensaje, Conversacion, Favorito
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate

class NotificacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notificacion
        fields = ['id', 'tipo', 'mensaje', 'fecha', 'leida']

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = ['usuario_id', 'nombre', 'correo_electronico', 'telefono', 'tipo_usuario', 'password', 'fecha_registro']
        extra_kwargs = {'password': {'write_only': True}}  # No devolver la contraseña

class MensajeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mensaje
        fields = ['id', 'conversacion', 'remitente', 'texto', 'fecha_envio', 'visto']

class ConversacionSerializer(serializers.ModelSerializer):
    # Serializa los mensajes asociados a la conversación
    mensajes = MensajeSerializer(many=True, read_only=True)
    
    class Meta:
        model = Conversacion
        fields = ['id', 'comprador', 'agente', 'propiedad', 'fecha_creacion', 'mensajes']

class FavoritoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Favorito
        fields = ['usuario', 'propiedad', 'fecha_agregado']