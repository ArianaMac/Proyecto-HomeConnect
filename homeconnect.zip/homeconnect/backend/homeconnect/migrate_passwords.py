import django
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'homeconnect.settings')
django.setup()

from core.models import Usuario

usuarios = Usuario.objects.all()
for usuario in usuarios:
    if usuario.contrasena and not usuario.password:
        usuario.set_password(usuario.contrasena)
        usuario.contrasena = ""  # Vaciar el campo "contrasena" si existía
        usuario.save()

print("Migración de contraseñas completada.")
